Forked from the Official NetlifyCMS Gatsby starter kit. Modifications to the original :

- Removed BulmaCSS
- Added TailwindCSS
- Added support for gatsby-background-image-es6
- Added FontAwesome
- Disabled previews (for now)
- Changed deisgn to some extent accordingly

