module.exports = () => ({
    plugins: [require('tailwindcss'), require('postcss-nesting')],
});
